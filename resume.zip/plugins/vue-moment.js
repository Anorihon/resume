import Vue from 'vue'
const moment = require('moment')

Vue.use(require('vue-moment'), {
  moment
})
